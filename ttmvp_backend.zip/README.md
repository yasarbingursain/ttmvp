# Strapi Backend

This is the backend setup for the TikTok-like app using Strapi.
